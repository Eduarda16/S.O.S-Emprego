<html lang="pt-BR" class="js svg background-fixed"><head>
       
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<title>S.O.S Emprego</title>
 <link rel="icon" type="imagem/png" href="/imagem/icons8-procurar-empregos-50.png" />
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//s.w.org">
<link href="https://fonts.gstatic.com" crossorigin="" rel="preconnect">
<link rel="alternate" type="application/rss+xml" title="Feed para S.O.S Emprego »" href="http://localhost/wordpress/feed/">
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para S.O.S Emprego »" href="http://localhost/wordpress/comments/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/wordpress\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.3"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="http://localhost/wordpress/wp-includes/js/wp-emoji-release.min.js?ver=5.2.3" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="wp-block-library-css" href="http://localhost/wordpress/wp-includes/css/dist/block-library/style.min.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wp-block-library-theme-css" href="http://localhost/wordpress/wp-includes/css/dist/block-library/theme.min.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="twentyseventeen-fonts-css" href="https://fonts.googleapis.com/css?family=Libre+Franklin%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C800%2C800i&amp;subset=latin%2Clatin-ext" type="text/css" media="all">
<link rel="stylesheet" id="twentyseventeen-style-css" href="http://localhost/wordpress/wp-content/themes/twentyseventeen/style.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="twentyseventeen-block-style-css" href="http://localhost/wordpress/wp-content/themes/twentyseventeen/assets/css/blocks.css?ver=1.1" type="text/css" media="all">
<link rel="stylesheet" id="twentyseventeen-colors-dark-css" href="http://localhost/wordpress/wp-content/themes/twentyseventeen/assets/css/colors-dark.css?ver=1.0" type="text/css" media="all">
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentyseventeen-ie8-css'  href='http://localhost/wordpress/wp-content/themes/twentyseventeen/assets/css/ie8.css?ver=1.0' type='text/css' media='all' />
<![endif]-->
<link rel="stylesheet" id="wpcvp_bootstrap-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/bootstrap.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_glyphicon-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/glyphicon.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_style-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/wp_curriculo_style.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_bugs-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/bugs.php?ver=5.2.3" type="text/css" media="all">
<!--[if lt IE 9]>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/themes/twentyseventeen/assets/js/html5.js?ver=3.7.3'></script>
<![endif]-->
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/popper.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/bootstrap.min.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/jquery.maskedinput-1.1.4.pack.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/scriptArea.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/script.js?ver=5.2.3"></script>
<link rel="https://api.w.org/" href="http://localhost/wordpress/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/wordpress/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/wordpress/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 5.2.3">
<link rel="canonical" href="http://localhost/wordpress/">
<link rel="shortlink" href="http://localhost/wordpress/">
<link rel="alternate" type="application/json+oembed" href="http://localhost/wordpress/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwordpress%2F">
<link rel="alternate" type="text/xml+oembed" href="http://localhost/wordpress/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwordpress%2F&amp;format=xml">

<script type="text/javascript">
var ajaxurl = 'http://localhost/wordpress/wp-admin/admin-ajax.php';

/*Função Pai de Mascaras*/
function Mascara(o,f){
		v_obj=o
		v_fun=f
		setTimeout("execmascara()",1)
}

/*Função que Executa os objetos*/
function execmascara(){
		v_obj.value=v_fun(v_obj.value)
}

/*Função que Determina as expressões regulares dos objetos*/
function leech(v){
		v=v.replace(/o/gi,"0")
		v=v.replace(/i/gi,"1")
		v=v.replace(/z/gi,"2")
		v=v.replace(/e/gi,"3")
		v=v.replace(/a/gi,"4")
		v=v.replace(/s/gi,"5")
		v=v.replace(/t/gi,"7")
		return v
}

/*Função que permite apenas numeros*/
function Integer(v){
		return v.replace(/\D/g,"")
}

/*Função que padroniza CPF*/
function Cpf(v){
		v=v.replace(/\D/g,"")
		v=v.replace(/(\d{3})(\d)/,"$1.$2")
		v=v.replace(/(\d{3})(\d)/,"$1.$2")

		v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2")

		return v
}
</script>
		<style id="twentyseventeen-custom-header-styles" type="text/css">
				.site-title a,
		.colors-dark .site-title a,
		.colors-custom .site-title a,
		body.has-header-image .site-title a,
		body.has-header-video .site-title a,
		body.has-header-image.colors-dark .site-title a,
		body.has-header-video.colors-dark .site-title a,
		body.has-header-image.colors-custom .site-title a,
		body.has-header-video.colors-custom .site-title a,
		.site-description,
		.colors-dark .site-description,
		.colors-custom .site-description,
		body.has-header-image .site-description,
		body.has-header-video .site-description,
		body.has-header-image.colors-dark .site-description,
		body.has-header-video.colors-dark .site-description,
		body.has-header-image.colors-custom .site-description,
		body.has-header-video.colors-custom .site-description {
			color: #000000;
		}
                 .menu a:hover{
    color:white;
    background-color: gray;
    height: 50px;
    padding: 20px;
		</style>
		</head>

<body class="home page-template-default page page-id-15 wp-embed-responsive twentyseventeen-front-page has-header-image page-one-column colors-dark">
<div id="page" class="site">


	<header id="masthead" class="site-header" role="banner">
            
		<div class="custom-header" style="margin-bottom: 0px;">

		<div class="custom-header-media">
			<div id="wp-custom-header" class="wp-custom-header"><img src="http://localhost/wordpress/wp-content/uploads/2019/09/eadddd.jpg" width="945" height="630" alt="S.O.S Emprego" srcset="http://localhost/wordpress/wp-content/uploads/2019/09/eadddd.jpg 945w, http://localhost/wordpress/wp-content/uploads/2019/09/eadddd-300x200.jpg 300w, http://localhost/wordpress/wp-content/uploads/2019/09/eadddd-768x512.jpg 768w" sizes="100vw"></div>		</div>

	<div class="site-branding" style="margin-bottom: 72px;">
	<div class="wrap">

		
		
							<h1 class="site-title"><a rel="home">S.O.S Emprego</a></h1>
			
                                                        <p class="site-description">Cansado de ficar de loja em loja entregando currículos? Seus problemas acabaram!</p>
					<!-- .site-branding-text -->

		
	</div><!-- .wrap -->
</div><!-- .site-branding -->

</div><!-- .custom-header -->

					<div class="navigation-top">
				<div class="wrap">
					<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="Menu do topo">
	<button class="menu-toggle" aria-controls="top-menu" aria-expanded="false">
		<svg class="icon icon-bars" aria-hidden="true" role="img"> <use href="#icon-bars" xlink:href="#icon-bars"></use> </svg><svg class="icon icon-close" aria-hidden="true" role="img"> <use href="#icon-close" xlink:href="#icon-close"></use> </svg>Menu	</button>

                <div class="menu-cadastre-seu-curriculo-container"><ul id="top-menu" class="menu"><li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-47"><a href="cadastro.php">Cadastre seu Curriculo</a></li>
                       
</ul></div>
			
	</nav><!-- #site-navigation -->
				</div><!-- .wrap -->
			</div><!-- .navigation-top -->
		
	</header><!-- #masthead -->

	
	<div class="site-content-contain">
		<div id="content" class="site-content">

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">

		<article id="post-15" class="twentyseventeen-panel  post-15 page type-page status-publish hentry">

	
	<div class="panel-content">
		<div class="wrap">
			<header class="entry-header">
				<h2 class="entry-title">Página inicial</h2>
				
			</header><!-- .entry-header -->

			<div class="entry-content">
				<p>Bem-vindo(a)! Encontre sua vaga e deixe seu currículo. Queremos te ajudar!</p>
			</div><!-- .entry-content -->

		</div><!-- .wrap -->
	</div><!-- .panel-content -->

</article><!-- #post-15 -->

		


	</main><!-- #main -->
</div><!-- #primary -->


		</div><!-- #content -->

		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="wrap">
				

	<aside class="widget-area" role="complementary" aria-label="Rodapé">
					<div class="widget-column footer-widget-2">
                                            <section id="text-5" class="widget widget_text"><h2 class="widget-title">Sobre este site</h2>			<div class="textwidget"><p>Site criado com o intuito de facilitar a vida daqueles que estão à procura de emprego.</p>
</div>
		</section>			</div>
            
			</aside><!-- .widget-area -->
 <center> <footer>
                    <small>&copy; Copyright 2018, sosemprego@gmail.com </small>
                </footer>   </center>
                        <nav class="social-navigation" role="navigation" aria-label="Menu de links sociais do rodapé"></nav>