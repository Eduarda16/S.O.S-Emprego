<html xmlns="http://www.w3.org/1999/xhtml" class="wp-toolbar" lang="pt-BR"><!--<![endif]--><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Novo cadastro ‹ S.O.S Emprego</title>
<script type="text/javascript">
addLoadEvent = function(func){if(typeof jQuery!="undefined")jQuery(document).ready(func);else if(typeof wpOnload!='function'){wpOnload=func;}else{var oldonload=wpOnload;wpOnload=function(){oldonload();func();}}};
var ajaxurl = '/wordpress/wp-admin/admin-ajax.php',
	pagenow = 'curriculo-vitae_page_formulario-premium-admin',
	typenow = '',
	adminpage = 'curriculo-vitae_page_formulario-premium-admin',
	thousandsSeparator = '.',
	decimalPoint = ',',
	isRtl = 0;
</script>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="dns-prefetch" href="//s.w.org">
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}

</style>
	

					</div>

		
<div id="wpbody" role="main">

<div id="wpbody-content">
		<div id="screen-meta" class="metabox-prefs">

			<div id="contextual-help-wrap" class="hidden no-sidebar" tabindex="-1" aria-label="Aba de ajuda contextual">
				<div id="contextual-help-back"></div>
				<div id="contextual-help-columns">
					<div class="contextual-help-tabs">
						<ul>
												</ul>
					</div>

					
					<div class="contextual-help-tabs-wrap">
											</div>
				</div>
			</div>
				</div>
		
	<h1>Novo cadastro</h1>



    <div class="container-fluid">

     <form id="wp-curriculo-cadastro" name="wp-curriculo-cadastro" method="post" enctype="multipart/form-data">
        <input type="hidden" name="tipoF" value="site">

        
          <input type="hidden" name="mod" value="new">
          <input type="hidden" name="excluirConta" value="0">

        
    <div class="tab-content pt-3" id="myTabContent">

        <div id="dadosPessoais" role="tabpanel">
            <h4><b>Dados pessoais:</b></h4>
            <div>
            <div class="row">
              <div class="col-12 col-md-8">
                <div class="form-group">
                  <label>Nome:</label>
                  <input type="text" name="nome" id="nome" class="form-control form-control-sm" value="">

                </div>
              </div>
                <div class="col-12 col-md-4">
                	  <div class="form-group">
                      <label>Sexo: </label>
                      <select class="form-control form-control-sm" name="sexo">
                        <option></option>
                        <option value="0">Feminino</option>
                        <option value="1">Masculino</option>
                      </select>
                    </div>
                </div>
                <div class="w-100"></div>
                <div class="col-12 col-md-4">
                    <div class="form-group">
                      <label>Estado cívil:</label>
                      <select name="estado_civil" class="form-control form-control-sm">
                          <option value="0"></option>
                          <option value="1">Solteiro(a)</option>
                          <option value="2">Viuvo(a)</option>
                          <option value="3">Casado(a)</option>
                          <option value="4">Divorciado(a)</option>
                          <option value="5">Amigável</option>
                      </select>

                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="form-group">
                      <label>Data de nascimento:</label>
                      <input type="date" name="idade" value="" class="form-control form-control-sm">

                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="form-group">
                      <label>Telefone:</label>
                      <input type="tel" name="telefone" value="" class="form-control form-control-sm telefone">

                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="form-group">
                      <label>Celular:</label>
                      <input type="tel" name="celular" value="" class="form-control form-control-sm telefone">
                    </div>
                </div>

              <div class="col-12 col-md-4">
                <div class="form-group">
                  <label>Email:</label>
                  <input type="email" name="email" value="" class="form-control form-control-sm">
                </div>
              </div>
              <div class="col-12 col-md-4">
                <div class="form-group">
                  <label>Skype:</label>
                  <input type="text" name="skype" value="" class="form-control form-control-sm">
                </div>
              </div>

              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                <div class="form-group">
                  <label>Site/blog:</label>
                  <input type="url" name="site_blog" value="" class="form-control form-control-sm">
                </div>
              </div>
            <div class="w-100"></div>
                <div class="col-12 col-md-6">
                    <div class="form-group">
                                            <label>Cargo Pretendido:</label>

                        <select name="id_area" class="form-control form-control-sm" id="id_area">
                          <option value="0">Selecione um cargo</option>
                                                        <option value="1">Administração</option>
                                                        <option value="4">Engenharia</option>
                                                        <option value="2">Finanças/Contabilidade</option>
                                                        <option value="6">Jurídica</option>
                                                        <option value="7">Logística/Suprimentos</option>
                                                        <option value="8">Marketing</option>
                                                        <option value="3">Mercado Financeiro/Seguros</option>
                                                        <option value="9">Recursos Humanos</option>
                                                        <option value="5">Tecnologia da Informação</option>
                                                        <option value="10">Vendas</option>
                                                                            </select>

                    </div>
                </div>
                <div class="col-12 col-md-6">

                    <div class="input-group input-group-sm" id="campoArea" style="display:none;">
                      <label for="area">Escreva seu cargo:</label>
                      <div class="w-100"></div>
                      <input type="text" class="form-control" name="area" id="area">
                    </div>

                </div>
<div class="w-100"></div>
              <div class="col-12 col-md-4">

                <div class="form-group">
                  <label>Pretenção Salarial:</label>
                  <input type="text" name="remuneracao" value="" class="form-control form-control-sm">

                </div>
              </div>

                <div class="col-12 col-md-4">
                    <div class="form-group">
                      <label>Login:</label>
                      <input type="text" name="login" value="" class="form-control form-control-sm">
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="form-group">
                      <label>Senha:</label>
                      <input type="password" name="senha" value="" class="form-control form-control-sm">
                    </div>
                </div>

                <div class="col-12 col-md-4">
                  <div class="input-group input-group-sm">
                    <label for="wpcvpcpf">CPF</label>
                    <div class="w-100"></div>
                    <input type="text" class="form-control" name="cpf" id="wpcvpcpf" value="">
                  </div>
                </div>
                <div class="col-12 col-md-4">
                  <div class="form-group">
                    <label>CEP:</label>
                    <input type="text" name="cep" value="" class="form-control form-control-sm" id="wpcvpcep">
                  </div>
                </div>


                <div class="col-12 col-md-10">
                    <div class="form-group">
                    <label>Endereço:</label>
                    <input type="text" name="rua" id="rua" value="" class="form-control form-control-sm">
                  </div>
                </div>
                <div class="col-12 col-md-2">
                    <div class="form-group">
                      <label>Nº:</label>
                      <input type="text" name="numero" id="numero" value="" class="form-control form-control-sm">
                    </div>
                </div>

              <div class="col-12">

                <div class="form-group">
                  <label>Bairro:</label>
                  <input type="text" name="bairro" id="bairro" value="" class="form-control form-control-sm">
                </div>
              </div>

                <div class="col-12 col-md-10">
                    <div class="form-group cidade">
                      <label>Cidade:</label>
                        <input type="text" name="cidade" id="wpcvpcidade" value="" class="form-control form-control-sm">
                    </div>
                </div>
                <div class="col-12 col-md-2">
                    <div class="form-group estado">
                      <label>Estado:</label>
                      <input type="text" name="estado" id="estado" value="" class="form-control form-control-sm">
                    </div>
                </div>

              <div class="col-12">
                <div class="form-group">
                  <label>Resumo Profissional:</label>
                  <textarea class="form-control form-control-sm" name="descricao" rows="5"></textarea>
                </div>
              </div>
              <div class="col-12 col-md-2">
                <div class="card mt-2 pt-2 pr-2 pb-2 pl-2">
                                            <img id="fotoCurriculo" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/img/sem-foto.png" width="100">
                                    </div>
              </div>
              <div class="col-12 col-md-10">
                  <div class="form-group">

                    <label>Enviar foto:</label>

                    <div class="custom-file">
                      <input type="file" class="custom-file-input" name="foto" id="foto">
                      <label class="custom-file-label" for="foto">Selecione sua foto</label>
                    </div>

                  </div>
              </div>

            
              <div class="col-12 mt-3">
                <div class="form-group">
                  <label class="control-label">Enviar currículo:</label>

                  <div class="custom-file">
                    <input type="file" class="custom-file-input" name="curriculo" id="curriculo">
                    <label class="custom-file-label" for="foto">Selecione o arquivo</label>
                    <small id="curriculoHelpBlock" class="form-text text-muted">
  Não é permitido enviar arquivo com extensão <b><span id="ext"></span></b>. Extensões permitidas: <strong>pdf</strong>, <strong>doc</strong> e <strong>docx</strong>.
</small>
                  </div>
                </div>
              </div>
</div>

            </div>
            <div class="clearfix"></div>
        </div>

        <button type="submit" id="cadastrar" name="cadastrar" class="btn btn-success tbCadastrarSite float-left mt-3">
      <span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>Cadastrar</button>
    
    
  </div></form>


<div class="clear"></div></div><!-- wpbody-content -->
<div class="clear"></div></div><!-- wpbody -->
<div class="clear"></div></div><!-- wpcontent -->


	<div id="wp-auth-check-wrap" class="hidden">
	<div id="wp-auth-check-bg"></div>
	<div id="wp-auth-check">
	<br><br><br>
                    <a href="index.php"><li>Página Inicial</li></a>     
                    <br><br>
	</div>
	</div>
	</div>
	<link rel="stylesheet" id="wpcvp_bootstrap-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/bootstrap.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_glyphicon-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/glyphicon.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_style-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/wp_curriculo_style.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_bugs-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/bugs.php?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvp_Style-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/css/wp_curriculo_style.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="jquery-ui-core-css" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="bootstrap-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/admin/../css/bootstrap.min.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="glyphicon-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/admin/../css/glyphicon.css?ver=5.2.3" type="text/css" media="all">
<link rel="stylesheet" id="wpcvpa_style-css" href="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/admin/css/style.css?ver=5.2.3" type="text/css" media="all">

<script type="text/javascript">
/* <![CDATA[ */
var commonL10n = {"warnDelete":"Voc\u00ea est\u00e1 prestes a excluir permanentemente estes itens do seu site.\nEsta a\u00e7\u00e3o n\u00e3o pode ser desfeita\n'Cancelar' para desistir, 'OK' para excluir.","dismiss":"Dispensar este aviso.","collapseMenu":"Contrair menu principal","expandMenu":"Expandir menu principal"};/* ]]> */
</script>
<script type="text/javascript" src="http://localhost/wordpress/wp-admin/load-scripts.php?c=1&amp;load%5B%5D=hoverIntent,common,admin-bar,svg-painter&amp;ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.0.0"></script>
<script type="text/javascript">
( 'fetch' in window ) || document.write( '<script src="http://localhost/wordpress/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="http://localhost/wordpress/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.26.0-0"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="http://localhost/wordpress/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="http://localhost/wordpress/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>' );
</script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/dist/hooks.min.js?ver=2.2.0"></script>
<script type="text/javascript">
/* <![CDATA[ */
var heartbeatSettings = {"nonce":"66c7766998"};
/* ]]> */

<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/wp-auth-check.min.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/popper.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/bootstrap.min.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/jquery.maskedinput-1.1.4.pack.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/scriptArea.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/wp-curriculo-vitae/js/script.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/jquery/ui/menu.min.js?ver=1.11.4"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/wp-sanitize.min.js?ver=5.2.3"></script>
<script type="text/javascript" src="http://localhost/wordpress/wp-includes/js/wp-a11y.min.js?ver=5.2.3"></script>
<script type="text/javascript">
/* <![CDATA[ */
var uiAutocompleteL10n = {"noResults":"Nenhum resultado encontrado.","oneResult":"Foi encontrado um resultado. Use as setas para cima e para baixo do teclado para navegar.","manyResults":"Foram encontrados %d resultados. Use as setas para cima e para baixo do teclado para navegar.","itemSelected":"Item selecionado."};
/* ]]> */
</script>


<div class="clear"></div></div><!-- wpwrap -->
<script type="text/javascript">if(typeof wpOnload=='function')wpOnload();</script>


</div><div id="wp-a11y-speak-polite" aria-live="polite" aria-relevant="additions text" aria-atomic="true" class="screen-reader-text wp-a11y-speak-region"></div><div id="wp-a11y-speak-assertive" aria-live="assertive" aria-relevant="additions text" aria-atomic="true" class="screen-reader-text wp-a11y-speak-region"></div></body></html>